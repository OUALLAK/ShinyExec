library(shiny)
library(e1071) # Pour "Asymétrie" et "Aplatissement"
library(class)  # Pour KNN
library(ggplot2)  # Pour la visualisation
library(viridis)
library(rpart)
library( rpart.plot)
library(shiny)
library(shinydashboard)
library(reactable)
library(shinythemes)
library(shinyjs)




ui <- dashboardPage(
  dashboardHeader(title = "Tableau de bord EDA"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Charger Données", tabName = "loadData", icon = icon("upload")),
      menuItem("Résumé Statistique", tabName = "summary", icon = icon("line-chart")),
      menuItem("Visualisation", tabName = "visualization", icon = icon("bar-chart")),
      menuItem("Machine Learning", icon = icon("cogs"),
               menuSubItem("Arbre de Décision", tabName = "decisionTree"),
               menuSubItem("KNN", tabName = "knn")
      )
    )
  ),

  dashboardBody(
    tags$head(includeCSS("styles.css")),
    tabItems(
      # Onglet pour charger les données
      tabItem(tabName = "loadData",
              fileInput("file1", "Choisissez le fichier CSV"),
              selectInput("nrows", "Nombre de lignes à afficher:",
                          choices = c("5" = 5, "10" = 10, "20" = 20, "Tout" = "All")),
              reactableOutput("dataTable")
      ),
      # Onglet pour le résumé statistique
      tabItem(tabName = "summary",
              fluidRow(
                uiOutput("variableSelect"),  # Sélection dynamique de la variable
                actionButton("calcButton", "Calculer")
              ),
              tableOutput("statSummary")
      ),
      # Onglet pour la visualisation
      tabItem(tabName = "visualization",
              fluidRow(
                column(4,
                       selectInput("graphType", "Type de graphique:",
                                   choices = c("Histogramme" = "hist", "Boîte à moustaches" = "boxplot", "Diagramme en bâtons" = "bar")),
                       uiOutput("graphVariableSelect")  # Mise à jour pour utiliser uiOutput
                ),
                column(8,
                       plotOutput("graphOutput")
                )
              )
      ),
      tabItem(tabName = "decisionTree",
              h2("Arbre de Décision"),
              uiOutput("targetVariableSelect"),
              uiOutput("predictorVariablesSelect"),
              actionButton("buildTree", "Construire l'Arbre de Décision"),
              plotOutput("treePlot")
      ),
      tabItem(tabName = "knn",
              h2("K-Nearest Neighbors (KNN)"),
              uiOutput("knnTargetVariableSelect"),
              uiOutput("knnPredictorVariablesSelect"),
              numericInput("kValue", "Nombre de voisins (k)", value = 5, min = 1),
              actionButton("runKnn", "Exécuter KNN"),
              plotOutput("knnPlot")
      )


    )
  )

)



server <- function(input, output) {

  # Stocker les données chargées de manière réactive
  reactiveData <- reactive({
    req(input$file1)
    inFile <- input$file1
    read.csv(inFile$datapath, header = TRUE)
  })

  # Mise à jour du selectInput pour les variables après le chargement des données
  output$variableSelect <- renderUI({
    req(reactiveData())
    selectInput("variable", "Choisissez une variable:",
                choices = names(reactiveData()))
  })

  # Calculer le nombre de lignes à afficher
  rowsToShow <- reactive({
    if (input$nrows == "All") {
      nrow(reactiveData())
    } else {
      as.numeric(input$nrows)
    }
  })

  output$dataTable <- renderReactable({
    req(reactiveData())
    reactable(reactiveData(),
              defaultPageSize = rowsToShow(),
              showPageSizeOptions = TRUE,
              pageSizeOptions = c(5, 10, 20, nrow(reactiveData()))
    )
  })
  output$statSummary <- renderTable({
    req(input$calcButton)
    var <- input$variable
    df <- reactiveData()

    if (is.null(df) || !var %in% names(df)) {
      return("Variable non trouvée ou données non chargées.")
    }

    selectedData <- df[[var]]

    # Création d'un dataframe pour le résumé statistique
    summary <- data.frame(
      Statistique = c("Moyenne", "Variance", "Écart Type", "Minimum", "Maximum",
                      "Quantile 25%", "Médiane", "Quantile 75%", "Asymétrie",
                      "Aplatissement", "Valeurs Manquantes"),
      Valeur = c(
        mean(selectedData, na.rm = TRUE),
        var(selectedData, na.rm = TRUE),
        sd(selectedData, na.rm = TRUE),
        min(selectedData, na.rm = TRUE),
        max(selectedData, na.rm = TRUE),
        quantile(selectedData, probs = 0.25, na.rm = TRUE),
        median(selectedData, na.rm = TRUE),
        quantile(selectedData, probs = 0.75, na.rm = TRUE),
        skewness(selectedData, na.rm = TRUE),  # Nécessite le package e1071
        kurtosis(selectedData, na.rm = TRUE),  # Nécessite le package e1071
        sum(is.na(selectedData))
      )
    )

    summary
  })

  # Mise à jour du selectInput pour les variables graphiques après le chargement des données
  output$graphVariableSelect <- renderUI({
    req(reactiveData())
    selectInput("graphVariable", "Choisissez une variable pour le graphique:",
                choices = names(reactiveData()))
  })

  # Générer et afficher le graphique
  output$graphOutput <- renderPlot({
    req(reactiveData(), input$graphVariable, input$graphType)
    df <- reactiveData()
    var <- input$graphVariable
    graphType <- input$graphType

    if (graphType == "hist") {
      ggplot(df, aes_string(x = var)) +
        geom_histogram(aes(fill = ..count..), color = "black") +
        scale_fill_viridis() +  # Utiliser viridis pour la couleur de remplissage
        labs(title = paste("Histogramme de", var), x = var, y = "Fréquence") +
        theme_minimal()
    } else if (input$graphType == "boxplot") {
      ggplot(df, aes(y = .data[[var]])) +
        geom_boxplot(fill = "#357ca6" ) +  # Utilisez une seule couleur de la palette viridis
        labs(title = paste("Boîte à moustaches de", var), y = var) +
        theme_minimal()
    } else if (graphType == "bar") {
      ggplot(df, aes_string(x = var, fill = as.factor(var))) +
        geom_bar() +
        scale_fill_viridis(discrete = TRUE) +  # Utiliser viridis pour la couleur de remplissage
        labs(title = paste("Diagramme en bâtons de", var), y = "Fréquence") +
        theme_minimal()
    }
  })


  # Mise à jour des choix des variables cible et prédictives
  output$targetVariableSelect <- renderUI({
    selectInput("targetVariable", "Choisissez la variable à prédire:",
                choices = names(reactiveData()))
  })

  output$predictorVariablesSelect <- renderUI({
    checkboxGroupInput("predictorVariables", "Choisissez les variables prédictives:",
                       choices = names(reactiveData()))
  })

  # Réactivité pour construire et afficher l'arbre de décision
  observeEvent(input$buildTree, {
    req(input$targetVariable, input$predictorVariables)
    formula <- as.formula(paste(input$targetVariable, "~", paste(input$predictorVariables, collapse = "+")))
    treeModel <- rpart(formula, data = reactiveData(), method = "class")

    output$treePlot <- renderPlot({
      rpart.plot(treeModel, main="Arbre de Décision", extra = 100)
    })
  })


  # Mise à jour des choix des variables pour KNN
  output$knnTargetVariableSelect <- renderUI({
    selectInput("knnTargetVariable", "Choisissez la variable cible pour KNN:",
                choices = names(reactiveData()))
  })

  output$knnPredictorVariablesSelect <- renderUI({
    checkboxGroupInput("knnPredictorVariables", "Choisissez les variables prédictives pour KNN:",
                       choices = names(reactiveData()))
  })

  observeEvent(input$runKnn, {
    req(input$knnTargetVariable, input$knnPredictorVariables, reactiveData())
    data <- reactiveData()

    # Préparation des données pour KNN
    targetVariable <- data[[input$knnTargetVariable]]
    predictorVariables <- data[, input$knnPredictorVariables, drop = FALSE]
    normData <- as.data.frame(lapply(predictorVariables, scale)) # Normalisation des variables prédictives

    # Création des ensembles d'entraînement et de test
    set.seed(123)  # Pour la reproductibilité
    trainIndex <- sample(1:nrow(data), 0.8 * nrow(data), replace = FALSE)
    trainData <- normData[trainIndex, ]
    testData <- normData[-trainIndex, ]
    trainLabels <- targetVariable[trainIndex]
    testLabels <- targetVariable[-trainIndex]

    # Exécution de KNN
    k <- input$kValue
    knnResult <- knn(train = trainData, test = testData, cl = trainLabels, k = k)

    # Calculer la précision
    accuracy <- sum(testLabels == knnResult) / length(testLabels)

    # Stocker le résultat dans une variable réactive pour l'utiliser dans la visualisation
    plotData <- reactive({
      data.frame(
        X = testData[, 1],  # La première colonne des données prédictives
        Y = testData[, 2],  # La deuxième colonne des données prédictives
        Predicted = as.factor(knnResult),
        Actual = as.factor(testLabels)
      )
    })

    # Afficher la précision
    output$knnResult <- renderText({
      paste("Précision de KNN:", accuracy)
    })

    # Visualisation des résultats de KNN
    output$knnPlot <- renderPlot({
      pd <- plotData()  # Récupération du plotData réactif

      # Vérifier que les variables sélectionnées pour la visualisation sont au nombre de deux
      if (length(input$knnPredictorVariables) != 2) {
        stop("Veuillez sélectionner exactement deux variables prédictives pour la visualisation.")
      }

      # Déterminer le nombre de couleurs nécessaires
      numColors <- length(unique(pd$Predicted))  # Nombre de catégories prédites
      numActual <- length(unique(pd$Actual))     # Nombre de catégories réelles
      maxCategories <- max(numColors, numActual)
      colors <- scales::hue_pal()(maxCategories)  # Utilise la palette 'hue' pour générer les couleurs

      # Utilisation de ggplot pour visualiser les données
      ggplot(pd, aes(x = X, y = Y)) +
        geom_point(aes(color = Predicted), size = 4, alpha = 0.6) +
        scale_color_manual(values = colors) +
        labs(title = "Résultats KNN", x = input$knnPredictorVariables[1], y = input$knnPredictorVariables[2], color = "Prédiction") +
        theme_minimal()
    })
  })

}

# Lancer l'application
shinyApp(ui = ui, server = server)
